#region Using declarations
using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using static NinjaTrader.NinjaScript.Indicators.KtnsFVGPercentMitigation;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class KtnsFVGPercentMitigation : Indicator
	{

        private double atrValue;
        private ATR atr;
        private List<FVG> fvgList = new List<FVG>();

        // Tracking variables for current FVG (renamed to avoid conflict)
        private double bullMitL = 0;
        private double bullMitC = 0;
        private double bullLow = 0;
        private double bullHigh = 0;
        private int fvgState = 0; // Changed from newFvg to fvgState

        private double bearMitH = 0;
        private double bearMitC = 0;
        private double bearLow = 0;
        private double bearHigh = 0;


        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Ktns Fair Value Gap Absorption Indicator with Alerts";
                Name = "KtnsFVGPercentMitigation";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                IsSuspendedWhileInactive = true;

                // Default settings
                AtrMultiplier = 0.5;
                ShowPercentage = true;
                ShowHistorical = true;
                FvgType = FvgTypeSelection.Bull;
                MitigationType = MitigationCalculationType.Wick;
                AlertType = AlertTypeSelection.Both;
                AlertPercent = 45;

                // Colors
                BullishImbalanceColor = Brushes.DarkSeaGreen;
                BullishMitigationColor = Brushes.Gray;
                BearishImbalanceColor = Brushes.IndianRed;
                BearishMitigationColor = Brushes.Gray;

                AddPlot(new Stroke(Brushes.Transparent, 2), PlotStyle.Dot, "BullishPercent");
                AddPlot(new Stroke(Brushes.Transparent, 2), PlotStyle.Dot, "BearishPercent");
            }
            else if (State == State.Configure)
            {
                atr = ATR(144);
            }
            else if (State == State.DataLoaded)
            {
                // Reset tracking variables
                bullMitL = 0;
                bullMitC = 0;
                bullLow = 0;
                bullHigh = 0;
                fvgState = 0;
                bearMitH = 0;
                bearMitC = 0;
                bearLow = 0;
                bearHigh = 0;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 144)
            {
                Values[0][0] = 0;
                Values[1][0] = 0;
                return;
            }
            Values[0][0] = double.NaN;
            Values[1][0] = double.NaN;

            try
            {
                atrValue = atr[0] * AtrMultiplier;

                // Store previous active count before checking new FVGs
                int previousActiveCount = fvgList.Count;

                // Check for new FVGs first
                CheckForNewFVG();

                // If new FVG was created, close all previous active FVGs
                if (fvgList.Count > previousActiveCount)
                {
                    for (int i = fvgList.Count - 2; i >= 0; i--) // Skip the newly added one
                    {
                        var oldFvg = fvgList[i];
                        if (!ShowHistorical)
                        {
                            RemoveFvgRectangles(oldFvg);
                        }
                        fvgList.RemoveAt(i);
                    }
                }

                // Update existing FVGs
                UpdateExistingFVGs();

                // Update tracking variables
                UpdateTrackingVariables();
                //Values[0][0] = 0;
                //Values[1][0] = 0;
            }
            catch (Exception ex)
            {
                Print("Error in OnBarUpdate: " + ex.Message);
            }
        }

        private void CheckForNewFVG()
        {
            bool bullG = Low[0] > High[1];
            bool bearG = High[0] < Low[1];

            // Bullish FVG condition
            if ((FvgType == FvgTypeSelection.Bull || FvgType == FvgTypeSelection.Both) &&
                (Low[0] - High[2]) > atrValue &&
                Low[0] > High[2] &&
                Close[1] > High[2] &&
                !(bullG || (Low[0] > High[1] && Low[1] > High[2])))
            {
                fvgState = 1;
                bullLow = High[2];
                bullHigh = Low[0];
                bullMitL = Low[0];
                bullMitC = Low[0];

                var newFvg = new FVG
                {
                    Type = FvgTypeSelection.Bull,
                    StartBar = CurrentBar - 1,
                    EndBar = CurrentBar,
                    Top = High[2],
                    Bottom = Low[0],
                    MitigationTop = Low[0],
                    MitigationBottom = Low[0],
                    IsAlertTriggered = false
                };

                DrawFvgRectangles(newFvg);
                fvgList.Add(newFvg);
            }

            // Bearish FVG condition
            if ((FvgType == FvgTypeSelection.Bear || FvgType == FvgTypeSelection.Both) &&
                (Low[2] - High[0]) > atrValue &&
                High[0] < Low[2] &&
                Close[1] < Low[2] &&
                !(bearG || (High[0] < Low[1] && High[1] < Low[2])))
            {
                fvgState = -1;
                bearLow = High[0];
                bearHigh = Low[2];
                bearMitH = High[0];
                bearMitC = High[0];

                var newFvg = new FVG
                {
                    Type = FvgTypeSelection.Bear,
                    StartBar = CurrentBar - 1,
                    EndBar = CurrentBar,
                    Top = High[0],
                    Bottom = Low[2],
                    MitigationTop = High[0],
                    MitigationBottom = High[0],
                    IsAlertTriggered = false
                };

                DrawFvgRectangles(newFvg);
                fvgList.Add(newFvg);
            }
        }

        private bool IsFvgComplete(FVG fvg)
        {
            // FVG is complete if:
            // 1. Price crossed through it OR
            // 2. Another FVG has formed (handled in OnBarUpdate)
            if (fvg.Type == FvgTypeSelection.Bull)
            {
                return Close[0] < fvg.Bottom;
            }
            else // Bearish
            {
                return Close[0] > fvg.Top;
            }
        }

        private void UpdateTrackingVariables()
        {
            // Update bullish mitigation tracking
            if (fvgState == 1 && Low[0] < bullMitL)
                bullMitL = Low[0];

            if (fvgState == 1 && Math.Min(Open[0], Close[0]) < bullMitC)
                bullMitC = Math.Min(Open[0], Close[0]);

            if (fvgState == 1 && Close[0] < bullLow)
            {
                bullLow = 0;
                bullHigh = 0;
            }

            // Update bearish mitigation tracking
            if (fvgState == -1 && High[0] > bearMitH)
                bearMitH = High[0];

            if (fvgState == -1 && Math.Max(Open[0], Close[0]) > bearMitC)
                bearMitC = Math.Max(Open[0], Close[0]);

            if (fvgState == -1 && Close[0] > bearHigh)
            {
                bearLow = 0;
                bearHigh = 0;
            }
        }

        private void UpdateExistingFVGs()
        {
            for (int i = fvgList.Count - 1; i >= 0; i--)
            {
                var fvg = fvgList[i];

                // Update rectangle positions
                UpdateFvgRectangles(fvg);

                // Check for mitigation
                CheckFvgMitigation(fvg);

                // Remove completed FVGs
                if (IsFvgComplete(fvg))
                {
                    if (!ShowHistorical)
                        RemoveFvgRectangles(fvg);
                    fvgList.RemoveAt(i);
                }
            }
        }

        private void DrawFvgRectangles(FVG fvg)
        {
            string tagBase = "FVG_" + fvg.StartBar;
            int startBarsAgo = CurrentBar - fvg.StartBar;
            int endBarsAgo = CurrentBar - fvg.EndBar;

            // Draw imbalance rectangle
            Draw.Rectangle(this, tagBase + "_Imbalance", true,
                startBarsAgo, fvg.Top,
                endBarsAgo, fvg.Bottom,
                fvg.Type == FvgTypeSelection.Bull ? BullishImbalanceColor : BearishImbalanceColor,
                fvg.Type == FvgTypeSelection.Bull ? BullishImbalanceColor : BearishImbalanceColor, 50);

            // Draw mitigation rectangle
            Draw.Rectangle(this, tagBase + "_Mitigation", true,
                startBarsAgo, fvg.MitigationTop,
                endBarsAgo, fvg.MitigationBottom,
                fvg.Type == FvgTypeSelection.Bull ? BullishMitigationColor : BearishMitigationColor,
                fvg.Type == FvgTypeSelection.Bull ? BullishMitigationColor : BearishMitigationColor, 50);

            // Draw percentage text
            if (ShowPercentage)
            {
                double midPrice = (fvg.Top + fvg.Bottom) / 2;
                Draw.Text(this, tagBase + "_Text", "",
                    startBarsAgo, midPrice, Brushes.White);
            }
        }

        private void UpdateFvgRectangles(FVG fvg)
        {
            string tagBase = "FVG_" + fvg.StartBar;
            int startBarsAgo = CurrentBar - fvg.StartBar;
            int currentBarsAgo = 0; // Current bar

            // Remove old rectangles first
            RemoveDrawObject(tagBase + "_Imbalance");
            RemoveDrawObject(tagBase + "_Mitigation");

            // Redraw with updated positions
            Draw.Rectangle(this, tagBase + "_Imbalance", true,
                startBarsAgo, fvg.Top,
                currentBarsAgo, fvg.Bottom,
                fvg.Type == FvgTypeSelection.Bull ? BullishImbalanceColor : BearishImbalanceColor,
                fvg.Type == FvgTypeSelection.Bull ? BullishImbalanceColor : BearishImbalanceColor, 50);

            Draw.Rectangle(this, tagBase + "_Mitigation", true,
                startBarsAgo, fvg.MitigationTop,
                currentBarsAgo, fvg.MitigationBottom,
                fvg.Type == FvgTypeSelection.Bull ? BullishMitigationColor : BearishMitigationColor,
                fvg.Type == FvgTypeSelection.Bull ? BullishMitigationColor : BearishMitigationColor, 50);

            // Update text position
            if (ShowPercentage)
            {
                RemoveDrawObject(tagBase + "_Text");

                double midPrice = (fvg.Top + fvg.Bottom) / 2;
                string text = "";

                if (fvg.Type == FvgTypeSelection.Bull && fvg.Top != fvg.Bottom)
                {
                    double percent = ((fvg.MitigationBottom - fvg.Bottom) / (fvg.Top - fvg.Bottom)) * 100;
                    text = string.Format("{0:F1}%", percent);
                }
                else if (fvg.Type == FvgTypeSelection.Bear && fvg.Top != fvg.Bottom)
                {
                    double percent = ((fvg.MitigationTop - fvg.Bottom) / (fvg.Top - fvg.Bottom)) * 100;
                    text = string.Format("{0:F1}%", percent);
                }

                Draw.Text(this,
                       tagBase + "_Text",       // Unique tag
                       true,                     // isAutoScale
                       text,                     // Text to display
                       startBarsAgo,             // barsAgo
                       midPrice,                 // y-price level
                       0,                        // yPixelOffset (adjust if needed)
                       Brushes.White,             // textBrush (foreground color)
                       new Gui.Tools.SimpleFont("Arial", 10), // Font
                       TextAlignment.Center,     // alignment
                       Brushes.Transparent,             // outlineBrush
                       Brushes.White,       // areaBrush (background)
                       70                         // areaOpacity (0 for transparent)
                   );
            }
        }

        private void CheckFvgMitigation(FVG fvg)
        {
            double mitigationPercent = 0;
            bool isFullyMitigated = false;

            if (fvg.Type == FvgTypeSelection.Bull)
            {
                // Update mitigation area based on selected type
                if (MitigationType == MitigationCalculationType.Wick)
                    fvg.MitigationBottom = Math.Min(fvg.MitigationBottom, Low[0]);
                else // Body
                    fvg.MitigationBottom = Math.Min(fvg.MitigationBottom, Math.Min(Open[0], Close[0]));

                // Check if fully mitigated (price reached bottom of FVG)
                isFullyMitigated = Close[0] <= fvg.Bottom;

                // INVERTED PERCENTAGE CALCULATION (100% → untouched, 0% → fully filled)
                if (fvg.Top != fvg.Bottom) // Avoid division by zero
                {
                    double gapSize = fvg.Top - fvg.Bottom;
                    double filledSize = fvg.Top - fvg.MitigationBottom;
                    mitigationPercent = 100 - Math.Min(100, Math.Max(0, (filledSize / gapSize) * 100));

                    Values[0][0] = mitigationPercent;

                    if (ShowPercentage)
                    {
                        string tagBase = "FVG_" + fvg.StartBar;
                        double midPrice = (fvg.Top + fvg.Bottom) / 2;
                        Draw.Text(this, tagBase + "_Text", $"{mitigationPercent:F1}%",
                            CurrentBar - fvg.StartBar, midPrice, Brushes.Black);
                    }

                    // Alert when remaining percentage <= (100 - AlertPercent)
                    // Example: AlertPercent=45 → trigger when <=55% remaining (45% filled)
                    if (mitigationPercent >= (100 - AlertPercent) && !fvg.IsAlertTriggered &&
                        (AlertType == AlertTypeSelection.Bullish || AlertType == AlertTypeSelection.Both))
                    {
                        fvg.IsAlertTriggered = true;
                        Draw.ArrowUp(this, "Alert_" + fvg.StartBar, true, 0,
                            Low[0] - TickSize * 5, Brushes.Green);
                    }
                }
            }
            else // Bearish FVG
            {
                // Update mitigation area based on selected type
                if (MitigationType == MitigationCalculationType.Wick)
                    fvg.MitigationTop = Math.Max(fvg.MitigationTop, High[0]);
                else // Body
                    fvg.MitigationTop = Math.Max(fvg.MitigationTop, Math.Max(Open[0], Close[0]));

                // Check if fully mitigated (price reached top of FVG)
                isFullyMitigated = Close[0] >= fvg.Top;

                // INVERTED PERCENTAGE CALCULATION (100% → untouched, 0% → fully filled)
                if (fvg.Top != fvg.Bottom) // Avoid division by zero
                {
                    double gapSize = fvg.Top - fvg.Bottom;
                    double filledSize = fvg.MitigationTop - fvg.Bottom;
                    mitigationPercent = 100 - Math.Min(100, Math.Max(0, (filledSize / gapSize) * 100));

                    Values[1][0] = mitigationPercent;

                    if (ShowPercentage)
                    {
                        string tagBase = "FVG_" + fvg.StartBar;
                        double midPrice = (fvg.Top + fvg.Bottom) / 2;
                        Draw.Text(this, tagBase + "_Text", $"{mitigationPercent:F1}%",
                            CurrentBar - fvg.StartBar, midPrice, Brushes.Black);
                    }

                    // Alert when remaining percentage <= (100 - AlertPercent)
                    if (mitigationPercent >= (100 - AlertPercent) && !fvg.IsAlertTriggered &&
                        (AlertType == AlertTypeSelection.Bearish || AlertType == AlertTypeSelection.Both))
                    {
                        fvg.IsAlertTriggered = true;
                        Draw.ArrowDown(this, "Alert_" + fvg.StartBar, true, 0,
                            High[0] + TickSize * 5, Brushes.Red);
                    }
                }
            }

            // Remove FVG if fully mitigated (0%)
            if (isFullyMitigated)
            {
                Draw.Text(this, fvg.StartBar + "_FilledX",false,
                        "X",
                        0,
                        Low[0] - TickSize * 10,
                        0,
                        Brushes.White,
                        new Gui.Tools.SimpleFont("Arial", 8),
                        TextAlignment.Center,
                        Brushes.Blue,
                        Brushes.LightBlue,
                        30
                    );
                if (!ShowHistorical)
                    RemoveFvgRectangles(fvg);
                fvgList.Remove(fvg);
            }
        }



        private void RemoveFvgRectangles(FVG fvg)
        {
            string tagBase = "FVG_" + fvg.StartBar;
            RemoveDrawObject(tagBase + "_Imbalance");
            RemoveDrawObject(tagBase + "_Mitigation");
            RemoveDrawObject(tagBase + "_Text");
        }



        #region Properties

        [Range(0, double.MaxValue)]
        [Display(Name = "FVG width filter", Description = "ATR multiplier for FVG width filter", Order = 1)]
        public double AtrMultiplier { get; set; }

        [Display(Name = "Show Percentage", Description = "Display percentage of mitigation", Order = 2)]
        public bool ShowPercentage { get; set; }

        [Display(Name = "Show Historical", Description = "Show historical FVGs", Order = 3)]
        public bool ShowHistorical { get; set; }

        [Display(Name = "Mitigation %", Description = "Percentage level for alerts", Order = 4)]
        public double AlertPercent { get; set; }

        [Display(Name = "FVG Type", Description = "Type of FVGs to display", Order = 5)]
        public FvgTypeSelection FvgType { get; set; }

        [Display(Name = "Mitigation Type", Description = "Use wick or body for mitigation", Order = 6)]
        public MitigationCalculationType MitigationType { get; set; }

        [Display(Name = "Alert Type", Description = "Type of alerts to generate", Order = 7)]
        public AlertTypeSelection AlertType { get; set; }

        [XmlIgnore]
        [Display(Name = "Bullish Imbalance Color", Order = 8)]
        public Brush BullishImbalanceColor { get; set; }

        [XmlIgnore]
        [Display(Name = "Bullish Mitigation Color", Order = 9)]
        public Brush BullishMitigationColor { get; set; }

        [XmlIgnore]
        [Display(Name = "Bearish Imbalance Color", Order = 10)]
        public Brush BearishImbalanceColor { get; set; }

        [XmlIgnore]
        [Display(Name = "Bearish Mitigation Color", Order = 11)]
        public Brush BearishMitigationColor { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Version", GroupName = "----- System -----", Order = 1)]
        [ReadOnly(true)]
        public string Version { get; set; } = "1.0.0";

        #endregion

        #region Nested Classes and Enums

        private class FVG
        {
            public FvgTypeSelection Type { get; set; }
            public int StartBar { get; set; }
            public int EndBar { get; set; }
            public double Top { get; set; }
            public double Bottom { get; set; }
            public double MitigationTop { get; set; }
            public double MitigationBottom { get; set; }
            public bool IsAlertTriggered { get; set; }
        }

        public enum FvgTypeSelection
        {
            [Description("Bullish Only")]
            Bull,
            [Description("Bearish Only")]
            Bear,
            [Description("Both")]
            Both
        }

        public enum MitigationCalculationType
        {
            [Description("Wick")]
            Wick,
            [Description("Body")]
            Body
        }

        public enum AlertTypeSelection
        {
            [Description("Bullish Only")]
            Bullish,
            [Description("Bearish Only")]
            Bearish,
            [Description("Both")]
            Both
        }

        #endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private KtnsFVGPercentMitigation[] cacheKtnsFVGPercentMitigation;
		public KtnsFVGPercentMitigation KtnsFVGPercentMitigation(string version)
		{
			return KtnsFVGPercentMitigation(Input, version);
		}

		public KtnsFVGPercentMitigation KtnsFVGPercentMitigation(ISeries<double> input, string version)
		{
			if (cacheKtnsFVGPercentMitigation != null)
				for (int idx = 0; idx < cacheKtnsFVGPercentMitigation.Length; idx++)
					if (cacheKtnsFVGPercentMitigation[idx] != null && cacheKtnsFVGPercentMitigation[idx].Version == version && cacheKtnsFVGPercentMitigation[idx].EqualsInput(input))
						return cacheKtnsFVGPercentMitigation[idx];
			return CacheIndicator<KtnsFVGPercentMitigation>(new KtnsFVGPercentMitigation(){ Version = version }, input, ref cacheKtnsFVGPercentMitigation);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.KtnsFVGPercentMitigation KtnsFVGPercentMitigation(string version)
		{
			return indicator.KtnsFVGPercentMitigation(Input, version);
		}

		public Indicators.KtnsFVGPercentMitigation KtnsFVGPercentMitigation(ISeries<double> input , string version)
		{
			return indicator.KtnsFVGPercentMitigation(input, version);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.KtnsFVGPercentMitigation KtnsFVGPercentMitigation(string version)
		{
			return indicator.KtnsFVGPercentMitigation(Input, version);
		}

		public Indicators.KtnsFVGPercentMitigation KtnsFVGPercentMitigation(ISeries<double> input , string version)
		{
			return indicator.KtnsFVGPercentMitigation(input, version);
		}
	}
}

#endregion
