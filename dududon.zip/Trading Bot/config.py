from logging import root
import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

def resource_path(relative_path):
    """Get absolute path to resource (works for .py and PyInstaller .exe)"""
    if hasattr(sys, '_MEIPASS'):  # PyInstaller temp folder
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


def get_config():
    def submit():
        try:
            config = {
                "symbol": symbol_entry.get(),
                "secType": sec_type_var.get(),
                "exchange": exchange_entry.get(),
                "currency": currency_entry.get(),
                "lastTradeDateOrContractMonth": contract_date_entry.get(),
                "stop_loss_points": int(stop_loss_entry.get()),
                "tp1_points": int(tp1_entry.get()),
                "tp2_points": int(tp2_entry.get()),
                "trailing_sl_points": int(trailing_sl_entry.get()),
                "polling_interval_ms": int(polling_entry.get()),
                "log_file": log_file_entry.get(),
                "monitor_log_file": monitor_log_entry.get(),
                "market_data_type": int(market_data_entry.get()),
                "tws_host": tws_host_entry.get(),
                "tws_port": int(tws_port_entry.get()),
                "client_id": int(client_id_entry.get()),
                "trading_hours": {
                    "enforce": enforce_hours_var.get(),
                    "start": start_time_combo.get(),
                    "end": end_time_combo.get()
                }
            }
            # messagebox.showinfo("Success", "Configuration submitted successfully!")
            # print(config)  # For debugging - replace with your actual processing
            root.config_data = config
            root.destroy()  # Close the config window so main.py can continue
        except ValueError as e:
            messagebox.showerror("Error", f"Invalid input: {e}")

    

    # Create main window
    root = tk.Tk()
    root.title("Trading Bot")

    try:
        icon_path = resource_path("logo/logo.ico")
        root.iconbitmap(icon_path)
    except Exception:
        pass  # Ignore if missing

    # ✅ Allow resizing
    root.resizable(True, True)  # (width, height) both resizable

    # ✅ Optional: set a minimum size so it doesn't shrink too much
    root.minsize(300, 400)

    # ✅ Optional: start at a bigger default size
    root.geometry("350x710")  # width x height


    # Create a frame with scrollbar
    main_frame = ttk.Frame(root)
    main_frame.pack(fill=tk.BOTH, expand=True)

    canvas = tk.Canvas(main_frame)
    scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
    scrollable_frame = ttk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    # Create all entry widgets
    row = 0

    # SYMBOL SECTION HEADING
    ttk.Label(scrollable_frame, text="Symbol Configuration", font=('Arial', 10, 'bold')).grid(row=row, column=0, columnspan=2, pady=10)
    row += 1

    # Symbol
    ttk.Label(scrollable_frame, text="Symbol:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    symbol_entry = ttk.Entry(scrollable_frame)
    symbol_entry.grid(row=row, column=1, padx=5, pady=2)
    symbol_entry.insert(0, "MNQ")
    row += 1

    # Product Type
    ttk.Label(scrollable_frame, text="Product Type:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    sec_type_var = tk.StringVar(value="FUT")
    sec_type_combo = ttk.Combobox(scrollable_frame, textvariable=sec_type_var,
                                values=["FUT", "STK", "CRYPTO", "ETF", "OPT", "CFD"], state="readonly")
    sec_type_combo.grid(row=row, column=1, padx=5, pady=2)
    row += 1


    # Exchange
    ttk.Label(scrollable_frame, text="Exchange:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    exchange_entry = ttk.Entry(scrollable_frame)
    exchange_entry.grid(row=row, column=1, padx=5, pady=2)
    exchange_entry.insert(0, "CME")
    row += 1

    # Currency
    ttk.Label(scrollable_frame, text="Currency:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    currency_entry = ttk.Entry(scrollable_frame)
    currency_entry.grid(row=row, column=1, padx=5, pady=2)
    currency_entry.insert(0, "USD")
    row += 1

    # Contract Date
    contract_date_row = row

    # Contract Date (initially hidden unless FUT)
    contract_date_label = ttk.Label(scrollable_frame, text="Contract Date :")
    contract_date_entry = ttk.Entry(scrollable_frame)
    contract_date_entry.insert(0, "20250919")
    row += 1

    def on_sec_type_change(event=None):
        sec_type = sec_type_var.get()

        if sec_type == "FUT":
            contract_date_label.grid(row=contract_date_row, column=0, sticky="w", padx=5, pady=2)
            contract_date_entry.grid(row=contract_date_row, column=1, padx=5, pady=2)
        else:
            contract_date_label.grid_remove()
            contract_date_entry.grid_remove()

        # Auto-fill exchange defaults
        if sec_type == "CRYPTO":
            exchange_entry.delete(0, tk.END)
            exchange_entry.insert(0, "PAXOS")
        elif sec_type in ["STK", "ETF"]:
            exchange_entry.delete(0, tk.END)
            exchange_entry.insert(0, "SMART")
        elif sec_type == "FUT":
            exchange_entry.delete(0, tk.END)
            exchange_entry.insert(0, "CME")
        elif sec_type == "OPT":
            exchange_entry.delete(0, tk.END)
            exchange_entry.insert(0, "SMART")
        elif sec_type == "CFD":
            exchange_entry.delete(0, tk.END)
            exchange_entry.insert(0, "SMART")

    # Bind selection change
    sec_type_combo.bind("<<ComboboxSelected>>", on_sec_type_change)

    # Call once to set initial state
    on_sec_type_change()


    # RISK MANAGEMENT SECTION HEADING
    ttk.Label(scrollable_frame, text="Risk Management", font=('Arial', 10, 'bold')).grid(row=row, column=0, columnspan=2, pady=10)
    row += 1

    # Stop Loss Points
    ttk.Label(scrollable_frame, text="Stop Loss Points:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    stop_loss_entry = ttk.Entry(scrollable_frame)
    stop_loss_entry.grid(row=row, column=1, padx=5, pady=2)
    stop_loss_entry.insert(0, "25")
    row += 1

    # Take Profit 1 Points
    ttk.Label(scrollable_frame, text="Take Profit 1 Points:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    tp1_entry = ttk.Entry(scrollable_frame)
    tp1_entry.grid(row=row, column=1, padx=5, pady=2)
    tp1_entry.insert(0, "25")
    row += 1

    # Take Profit 2 Points
    ttk.Label(scrollable_frame, text="Take Profit 2 Points:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    tp2_entry = ttk.Entry(scrollable_frame)
    tp2_entry.grid(row=row, column=1, padx=5, pady=2)
    tp2_entry.insert(0, "50")
    row += 1

    # Trailing Stop Loss Points
    ttk.Label(scrollable_frame, text="Trailing SL Points:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    trailing_sl_entry = ttk.Entry(scrollable_frame)
    trailing_sl_entry.grid(row=row, column=1, padx=5, pady=2)
    trailing_sl_entry.insert(0, "25")
    row += 1

    # Polling Interval (ms)
    ttk.Label(scrollable_frame, text="Polling Interval (ms):").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    polling_entry = ttk.Entry(scrollable_frame)
    polling_entry.grid(row=row, column=1, padx=5, pady=2)
    polling_entry.insert(0, "500")
    row += 1

    # LOGGING SECTION HEADING
    ttk.Label(scrollable_frame, text="Logging Configuration", font=('Arial', 10, 'bold')).grid(row=row, column=0, columnspan=2, pady=10)
    row += 1

    # Log File
    ttk.Label(scrollable_frame, text="Log File:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    log_file_entry = ttk.Entry(scrollable_frame)
    log_file_entry.grid(row=row, column=1, padx=5, pady=2)
    log_file_entry.insert(0, "trading_bot.csv")
    row += 1

    # Monitor Log File
    ttk.Label(scrollable_frame, text="Monitor Log File:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    monitor_log_entry = ttk.Entry(scrollable_frame)
    monitor_log_entry.grid(row=row, column=1, padx=5, pady=2)
    monitor_log_entry.insert(0, "live_monitor.log")
    row += 1

    # Market Data Type
    ttk.Label(scrollable_frame, text="Market Data Type:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    market_data_entry = ttk.Entry(scrollable_frame)
    market_data_entry.grid(row=row, column=1, padx=5, pady=2)
    market_data_entry.insert(0, "3")
    row += 1

    # TWS Host
    ttk.Label(scrollable_frame, text="TWS Host:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    tws_host_entry = ttk.Entry(scrollable_frame)
    tws_host_entry.grid(row=row, column=1, padx=5, pady=2)
    tws_host_entry.insert(0, "127.0.0.1")
    row += 1

    # TWS Port
    ttk.Label(scrollable_frame, text="TWS Port:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    tws_port_entry = ttk.Entry(scrollable_frame)
    tws_port_entry.grid(row=row, column=1, padx=5, pady=2)
    tws_port_entry.insert(0, "7497")
    row += 1

    # Client ID
    ttk.Label(scrollable_frame, text="Client ID:").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    client_id_entry = ttk.Entry(scrollable_frame)
    client_id_entry.grid(row=row, column=1, padx=5, pady=2)
    client_id_entry.insert(0, "1")
    row += 1

    # Trading Hours Section
    ttk.Label(scrollable_frame, text="Trading Hours", font=('Arial', 10, 'bold')).grid(row=row, column=0, columnspan=2, pady=10)
    row += 1

    # Enforce Trading Hours
    enforce_hours_var = tk.BooleanVar(value=True)
    ttk.Checkbutton(scrollable_frame, text="Enforce Trading Hours", variable=enforce_hours_var).grid(row=row, column=0, columnspan=2, sticky="w", padx=5, pady=2)
    row += 1

    # Generate list of times in HH:MM format every minute
    time_options = [f"{h:02d}:{m:02d}" for h in range(24) for m in range(0, 60, 1)]

    # Start Time
    ttk.Label(scrollable_frame, text="Start Time (HH:MM):").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    start_time_combo = ttk.Combobox(scrollable_frame, values=time_options, width=10)
    start_time_combo.grid(row=row, column=1, padx=5, pady=2)
    start_time_combo.set("09:30")  # default
    row += 1

    # End Time
    ttk.Label(scrollable_frame, text="End Time (HH:MM):").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    end_time_combo = ttk.Combobox(scrollable_frame, values=time_options, width=10)
    end_time_combo.grid(row=row, column=1, padx=5, pady=2)
    end_time_combo.set("16:30")  # default
    row += 1

    # Submit Button
    submit_btn = ttk.Button(root, text="Start", command=submit)
    submit_btn.pack(pady=10)



    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("App closed")

    return getattr(root, "config_data", None)