import sys
import threading
import time
import tkinter as tk
from tkinter.scrolledtext import ScrolledText
from ib_connector import IBConnector
from trading_strategy import MNQTradingStrategy
import config
import asyncio


class MonitorWindow:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Trading Bot Monitor")
        self.root.geometry("600x450")
        self.stop_flag = False

        # Monitor text area
        self.text_area = ScrolledText(self.root, wrap=tk.WORD, state='disabled')
        self.text_area.pack(fill=tk.BOTH, expand=True, pady=5)

        # Red Stop button
        self.stop_button = tk.Button(
            self.root,
            text="STOP",
            command=self.stop_bot,
            bg="red",
            fg="white",
            font=("Arial", 8, "bold"),
            padx=20,
            pady=10
        )
        self.stop_button.pack(pady=10)

        # Handle window close (X)
        self.root.protocol("WM_DELETE_WINDOW", self.stop_bot)
        

    def log(self, msg):
        self.text_area.config(state='normal')
        self.text_area.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
        self.text_area.see(tk.END)
        self.text_area.config(state='disabled')

    def stop_bot(self):
        self.stop_flag = True
        self.log("Stopping bot...")
        self.root.quit()  # Close Tkinter window

    def run(self):
        self.root.mainloop()

def read_ib_connection_log(monitor_ui, logfile="ib_connection.log"):
    try:
        with open(logfile, "r", encoding="utf-8") as f:
            for line in f:
                monitor_ui.log(line.strip())  # send to UI
    except FileNotFoundError:
        monitor_ui.log(f"Log file {logfile} not found.")



def bot_logic(monitor_ui, config_values):
    asyncio.set_event_loop(asyncio.new_event_loop())

    ib_conn = IBConnector(config_values)
    time.sleep(5)

    if not ib_conn.connect():
        monitor_ui.log("Could not connect: Make sure TWS or IB Gateway is running and you are logged in.")
        return
    
    monitor_ui.log(ib_conn.get_login_status())
    
    contract = ib_conn.get_contract()
    if not contract:
        monitor_ui.log("Contract resolution failed — bot will not start.")
        return

    strategy = MNQTradingStrategy(ib_conn, config_values)
        

    try:
        while not monitor_ui.stop_flag:
            status = strategy.manage_position()
            if status:
                monitor_ui.log(status)
            time.sleep(config_values['polling_interval_ms'] / 1000)
    except KeyboardInterrupt:
        monitor_ui.log("Shutting down...")
    finally:
        ib_conn.disconnect()
        monitor_ui.log("Disconnected from TWS")


if __name__ == "__main__":
    try:
        # 1️⃣ First, get config
        config_values = config.get_config()
        if not config_values:
            print("Configuration canceled. Bot not started.")
            sys.exit(0)

        # 2️⃣ Now open the monitor window
        monitor = MonitorWindow()


        # 3️⃣ Start bot logic in background thread
        threading.Thread(
            target=bot_logic,
            args=(monitor, config_values),
            daemon=True
        ).start()

        # 4️⃣ Run Tkinter UI
        monitor.run()

    except KeyboardInterrupt:
        print("\nBot stopped by user.")
        sys.exit(0)

