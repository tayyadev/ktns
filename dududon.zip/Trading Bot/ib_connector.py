import time
from ib_insync import IB, Future, Contract
import logging
from typing import Optional, Tuple
from datetime import datetime

class IBConnector:
    def __init__(self, config: dict):
        self.config = config
        self.ib = IB()
        self.logger = self._setup_logger()
        self._validate_config()
        self.market_data_type = config['market_data_type']  # Default to delayed data
        self._connection_attempts = 0
        self.max_retries =  5000
        self.retry_delay =  5 # seconds
        self._last_connection_time = None
        self.message_c = None

    def _setup_logger(self):
        logger = logging.getLogger('IBConnector')
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s,%(name)s,%(levelname)s,%(message)s')
        
        # File handler
        file_handler = logging.FileHandler('ib_connection.log')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        return logger

    def _validate_config(self):
        """Validate required configuration fields"""
        required_fields = [
            'tws_host', 'tws_port', 'client_id',
            'symbol', 'secType', 'exchange', 'currency'
        ]
        
        missing = [field for field in required_fields if field not in self.config]
        if missing:
            raise ValueError(f"Missing required config fields: {', '.join(missing)}")

    def connect(self) -> bool:
        """Establish connection to TWS with retry logic"""
        while self._connection_attempts < self.max_retries:
            try:
                self._connection_attempts += 1
                
                if not self.ib.isConnected():
                    self.logger.info(f"Attempting connection to TWS (attempt {self._connection_attempts})")
                    
                    self.ib.connect(
                        host=self.config['tws_host'],
                        port=self.config['tws_port'],
                        clientId=self.config['client_id'],
                        timeout=15
                    )
                
                if self.ib.isConnected():
                    # Verify connection with a simple request
                    server_time = self.ib.reqCurrentTime()
                    self.ib.reqMarketDataType(self.market_data_type)
                    
                    self._last_connection_time = datetime.now()
                    self.logger.info(
                        f"Successfully connected to TWS (v{self.ib.client.serverVersion()}) "
                        f"Server time: {server_time} "
                        f"Market Data Type: {self.market_data_type}"
                    )
                    return True
                
            except Exception as e:
                self.logger.warning(
                    f"Connection attempt {self._connection_attempts}/{self.max_retries} failed: {str(e)}"
                )
                if self._connection_attempts < self.max_retries:
                    time.sleep(self.retry_delay)

        
        self.logger.error(f"Failed to connect after {self.max_retries} attempts")
        return False 

    def disconnect(self):
        """Gracefully disconnect from TWS"""
        try:
            if self.ib.isConnected():
                self.ib.disconnect()
                self.logger.info("Disconnected from TWS")
        except Exception as e:
            self.logger.error(f"Error during disconnection: {e}")
        finally:
            self._connection_attempts = 0

    def get_contract(self) -> Optional[Contract]:
        """Resolve and validate the MNQ futures contract"""
        try:
            contract = Contract()
            contract.symbol = self.config['symbol']
            contract.secType = self.config['secType']
            contract.exchange = self.config['exchange']
            contract.currency = self.config['currency']

            # Only futures require expiry date
            if contract.secType == "FUT":
                contract.lastTradeDateOrContractMonth = self.config['lastTradeDateOrContractMonth']
            else:
                contract.lastTradeDateOrContractMonth = ""

            self.logger.info(f"Attempting to resolve contract: {contract}")
            
            # Request contract details for validation
            contracts = self.ib.reqContractDetails(contract)
            if not contracts:
                self.logger.error("No contract details found")
                return None
                
            validated_contract = contracts[0].contract
            self.logger.info(f"Successfully resolved contract: {validated_contract}")
            
            return validated_contract
            
        except Exception as e:
            self.logger.error(f"Contract resolution failed: {str(e)}")
            return None
        
    def get_login_status(self) -> str:
        """
        Returns a simple message about whether TWS is logged in (connected).
        """
        if self.ib.isConnected():
            return "Logged in to TWS"
        else:
            return "Not logged in - Please open TWS or IB Gateway and log in."


    def check_connection(self) -> Tuple[bool, Optional[str]]:
        """Check if connection is active and return status with optional error message"""
        if not self.ib.isConnected():
            return False, "Not connected to TWS"
            
        try:
            # Test connection with a lightweight request
            self.ib.reqCurrentTime()
            return True, None
        except Exception as e:
            return False, str(e)

    def reconnect(self) -> bool:
        """Reconnect to TWS with full handshake"""
        self.disconnect()
        time.sleep(1)  # Brief pause before reconnection attempt
        self._connection_attempts = 0  # Reset attempt counter
        return self.connect()
    
    

    def verify_contract_details(self, contract: Contract) -> bool:
        """Verify the contract details are still valid"""
        try:
            details = self.ib.reqContractDetails(contract)
            return len(details) > 0
        except Exception as e:
            self.logger.warning(f"Contract verification failed: {str(e)}")
            return False

    def __enter__(self):
        """Context manager entry point"""
        if not self.connect():
            raise ConnectionError("Failed to connect to TWS")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit point"""
        self.disconnect()