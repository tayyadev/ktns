import csv
import os
from datetime import datetime
import time
from ib_insync import StopOrder, MarketOrder, LimitOrder, StopLimitOrder
from matplotlib import ticker

class MNQTradingStrategy:
    def __init__(self, ib_connector, config):
        self.ib = ib_connector.ib
        self.config = config
        self.contract = ib_connector.get_contract()
        self.position = None
        self.entry_price = None
        self.original_size = 0
        self.sl_order = None
        self.tp1_triggered = False
        self.tp2_triggered = False
        self.highest_price = None
        self.multiplier = None  
        self.last_warning_minute = None
        self._init_csv_log()
        self.details = self.ib.reqContractDetails(self.contract)
        self.tick_size = None

        if self.details:
            self.tick_size = self.details[0].minTick
            print(f"Symbol: {self.config['symbol']} Tick Size: {self.tick_size}")
            self._log_to_monitor(f"Symbol: {self.config['symbol']} Tick Size: {self.tick_size}")
        else:
            print("No contract details available, using default tick size ")
            self._log_error.warning("No contract details available, using default tick size.")

        if getattr(self.contract, "multiplier", ""):
            try:
                self.multiplier = float(self.contract.multiplier)
            except ValueError:
                self.multiplier = 1.0
        

    def _log_to_monitor(self, message):
        monitor_log = self.config['monitor_log_file'] 
        with open(monitor_log, 'a') as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")


    def _init_csv_log(self):
        # Require log_file from config
        if 'log_file' not in self.config:
            raise ValueError("Missing 'log_file' in config")

        log_file = self.config['log_file']

        # Title Case headers with Message column
        header = ['Timestamp', 'Event', 'Symbol', 'Entry Price', 'Qty', 'Message']

        if not os.path.exists(log_file):
            with open(log_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(header)


    def _log_to_csv(self, event, message=""):
        try:
            
            if 'log_file' not in self.config:
                raise ValueError("Missing 'log_file' in config")

            log_file = self.config['log_file']
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            symbol = self.config.get('symbol', '')
            entry_price = f"{self.entry_price:.2f}" if self.entry_price else "-"
            qty = abs(self.position.position) if self.position else "-"

            with open(log_file, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([timestamp, event, symbol, entry_price, qty, message])
        except Exception as e:
            self._log_error(str(e), error_type="Execution")
            return f"{event} Error: {str(e)}"

    def _log_error(self, message, error_type="General"):
        """
        Log errors to both monitor log and CSV with error type.
        error_type examples: 'OrderRejected', 'API', 'Execution', etc.
        """
        error_msg = f"{error_type} Error: {message}"
        
        # Log to monitor file
        self._log_to_monitor(error_msg)
        
        # Log to CSV
        self._log_to_csv(f"Error - {error_type}", error_msg)

    def _is_trading_hours(self):
        """Check if current time is within configured trading hours."""
        try:
            thours = self.config.get("trading_hours", {})
            if not thours.get("enforce", False):
                return True  # No restriction

            if "start" not in thours or "end" not in thours:
                raise ValueError("Trading hours 'start' and 'end' must be set in config")

            start_str = thours["start"]
            end_str = thours["end"]

            start_time = datetime.strptime(start_str, "%H:%M").time()
            end_time = datetime.strptime(end_str, "%H:%M").time()
            now_time = datetime.now().time()

            return start_time <= now_time <= end_time
        except Exception as e:
            self._log_error(str(e), error_type="Config")
            return True  # Fail-safe: allow trading if error



    def manage_position(self):
        current_pos = self._check_position()

        # --- Case 1: There is a position from IBKR ---
        if current_pos:
            #  Check for outside trading hours warning
            if not self._is_trading_hours():
                now = datetime.now()
                if self.last_warning_minute is None or now.minute != self.last_warning_minute:
                    # Log only once per minute
                    self._log_to_monitor("Warning : Outside Trading Hours - Managing normally")
                    self._log_to_csv("OutsideTradingHours", "Warning : Position opened outside Trading Hours - Managing normally")
                    self.last_warning_minute = now.minute
                

            if self.position is None:
                self._initialize_position(current_pos)

                symbol = self.config.get("symbol", "UNKNOWN")
                position_type = "LONG" if current_pos.position > 0 else "SHORT"
                qty = abs(current_pos.position)
                usd_price = current_pos.avgCost
                index_price = usd_price / self.multiplier if hasattr(self, "multiplier") else usd_price

                self._log_to_monitor(f"New trade detected: {qty} {position_type} @ {usd_price:.2f} USD ({index_price:.2f} index)")
                self._log_to_csv(
                    event=f"New Position - {position_type}",
                    message=f"{symbol}{position_type} @ {usd_price:.2f} USD ({index_price:.2f} index), Qty: {qty}"
                )

                return f"New trade detected: {qty} {position_type} @ {usd_price:.2f}"

            current_dir = 1 if current_pos.position > 0 else -1
            prev_dir = 1 if self.position.position > 0 else -1

            if current_dir != prev_dir:
                self._initialize_position(current_pos)

                position_type = "LONG" if current_pos.position > 0 else "SHORT"
                qty = abs(current_pos.position)
                usd_price = current_pos.avgCost
                index_price = usd_price / self.multiplier if hasattr(self, "multiplier") else usd_price

                self._log_to_monitor(f"Direction change: {qty} {position_type} @ {usd_price:.2f} USD ({index_price:.2f} index)")
                self._log_to_csv(
                    event=f"Direction Change - {position_type}",
                    message=f"{position_type} @ {usd_price:.2f} USD ({index_price:.2f} index), Qty: {qty}"
                )

                return f"Direction change: {qty} {position_type} @ {usd_price:.2f}"

            if current_pos.position != self.position.position:
                self._initialize_position(current_pos)

                position_type = "LONG" if current_pos.position > 0 else "SHORT"
                qty = abs(current_pos.position)
                usd_price = current_pos.avgCost
                index_price = usd_price / self.multiplier if hasattr(self, "multiplier") else usd_price

                self._log_to_monitor(f"Position size change: {qty} {position_type} @ {usd_price:.2f} USD ({index_price:.2f} index)")
                self._log_to_csv(
                    event=f"Size Change - {position_type}",
                    message=f"{position_type} @ {usd_price:.2f} USD ({index_price:.2f} index), Qty: {qty}"
                )

                return f"Position size change: {qty} {position_type} @ {usd_price:.2f}"

            # Continuous management
            self.position = current_pos
            status_msg = self._execute_strategy()
            self._log_to_monitor(status_msg)  # <-- now logs every loop
            return status_msg

        elif not current_pos and self.position:
            reason = "Position closed"
            trigger_price = None

            # Try to determine why
            if self.sl_order:
                trigger_price = getattr(self.sl_order, 'auxPrice', None)  # SL price from order
                reason = "Closed by Stop Loss"
            elif getattr(self, 'tp1_triggered', False) and not getattr(self, 'tp2_triggered', False):
                reason = "Closed by Take Profit 1"
            elif getattr(self, 'tp2_triggered', False):
                reason = "Closed by Take Profit 2"
            else:
                reason = "Closed manually"

            # Build message
            if trigger_price:
                msg = f"{reason} at {trigger_price:.2f}"
            else:
                msg = reason

            # Log both reason and "Position closed"
            self._cleanup()
            self._log_to_monitor("Position closed")  # Extra note
            return msg


        # --- No active position ---
        self._log_to_monitor("Monitoring for positions...")
        return "Monitoring  positions..."



    def _check_position(self):
        # Force API to refresh positions from TWS
        self.ib.reqPositions()
        self.ib.sleep(0.5)
        positions = self.ib.positions()

        for pos in positions:
            if (pos.contract.symbol.upper() == self.config['symbol'].upper() and
                str(pos.contract.lastTradeDateOrContractMonth).startswith(str(self.config['lastTradeDateOrContractMonth']))):
                return pos
        return None


    def _execute_strategy(self):
        ticker = self.ib.reqMktData(self.contract, snapshot=False)
        self.ib.sleep(0.2)  # Wait for price update
        is_long = self.position.position > 0
        
        if is_long:
            current_price = ticker.ask  # use ask for long
        else:
            current_price = ticker.bid  # use bid for short

        
        if not current_price:
            return "Waiting for market data..."
        
        is_long = self.position.position > 0
        entry_price = self.entry_price / self.multiplier if self.entry_price else 0
        points_diff = (current_price - entry_price) * (1 if is_long else -1)
        # print(f"Current Price: {current_price}, Entry Price: {entry_price}, Diff: {current_price - entry_price:.2f}")
        
        # TP1 calculation
        if is_long:
            tp1_index_price = entry_price + self.config['tp1_points']
        else:
            tp1_index_price = entry_price - self.config['tp1_points']

         # TP2 calculation
        if is_long:
            tp2_index_price = entry_price + self.config['tp2_points']
        else:
            tp2_index_price = entry_price - self.config['tp2_points']

        

         # Align TP1 to MNQ tick size
        tp1_index_price = round(tp1_index_price / self.tick_size) * self.tick_size

        # Align TP2 to MNQ tick size
        tp2_index_price = round(tp2_index_price / self.tick_size) * self.tick_size

        # --- Log full strategy info ---
        self._log_to_monitor("\n=== Strategy Check ===")
        self._log_to_monitor(f"Position Type : {'LONG' if is_long else 'SHORT'}")
        self._log_to_monitor(f"Contracts     : {self.original_size}")
        self._log_to_monitor(f"Entry Price   : {self.entry_price:.2f} USD ({entry_price:.2f} index)")
        self._log_to_monitor(f"Market Price  : {current_price * self.multiplier:.2f} USD ({current_price:.2f} index)")
        self._log_to_monitor(f"TP1 Target    : {tp1_index_price * self.multiplier:.2f} USD ({tp1_index_price:.2f} index)")
        self._log_to_monitor(f"TP2 Target    : {tp2_index_price * self.multiplier:.2f} USD ({tp2_index_price:.2f} index)")
        self._log_to_monitor("=======================\n")

        # TP1 Logic
        if not self.tp1_triggered:
            if (is_long and current_price >= tp1_index_price) or (not is_long and current_price <= tp1_index_price):
                return self._execute_tp1(current_price, is_long)

        # TP2 Logic
        elif self.tp1_triggered and not self.tp2_triggered :
            if ((is_long and current_price >= tp2_index_price) or (not is_long and current_price <= tp2_index_price)):
                return self._execute_tp2(current_price, is_long)
        
        # Trailing Stop Logic
        elif self.tp2_triggered:
            return self._manage_trailing_stop(current_price, is_long)
        
        return f"Managing position: {points_diff:.1f} points {'profit' if points_diff >=0 else 'loss'}"

    def _initialize_position(self, position):
        try:
            # Cancel any existing SL order
            if self.sl_order:
                print("[DEBUG] Cancelling previous SL order before placing new one")
                self.ib.cancelOrder(self.sl_order)
                self.ib.sleep(1.5) 
                self.sl_order = None

            self.position = position
            self.entry_price = position.avgCost
            self.original_size = abs(position.position)

            # Get current market index price
            ticker = self.ib.reqMktData(self.contract, snapshot=False)
            is_long = position.position > 0
            self.ib.sleep(0.2)
            if is_long:
                market_price_index = ticker.ask
            else:
                market_price_index = ticker.bid

            market_price_usd = market_price_index * self.multiplier if market_price_index else 0
            entry_price_index = self.entry_price / self.multiplier

            # Determine SL index price
            if getattr(self, "tp1_triggered", False) and getattr(self, "tp1_fill_price", None):
                # Use TP1 fill price for breakeven SL
                sl_index_price = self.tp1_fill_price / self.multiplier
                self._just_tp1 = False
                print(f"[DEBUG] Using TP1 fill price for SL: {self.tp1_fill_price:.2f} USD ({sl_index_price:.2f} index)")
            else:
                # Default SL from entry price ± stop_loss_points
                if is_long:
                    sl_index_price = entry_price_index - self.config['stop_loss_points']
                else:
                    sl_index_price = entry_price_index + self.config['stop_loss_points']

            stop_price_index = round(sl_index_price / self.tick_size) * self.tick_size

            # Log position details
            self._log_to_monitor("\n=== New Position Initialized ===")
            self._log_to_monitor(f"Position Type : {'LONG' if is_long else 'SHORT'}")
            self._log_to_monitor(f"Contracts     : {self.original_size}")
            self._log_to_monitor(f"Entry Price   : {self.entry_price:.2f} USD ({entry_price_index:.2f} index)")
            self._log_to_monitor(f"Market Price  : {market_price_usd:.2f} USD ({market_price_index:.2f} index)")
            self._log_to_monitor(f"Stop Loss     : {stop_price_index * self.multiplier:.2f} USD ({stop_price_index:.2f} index)")
            self._log_to_monitor("===============================\n")

            # Place SL order
            self.sl_order = StopOrder(
                'SELL' if is_long else 'BUY',
                self.original_size,
                stop_price_index,
                tif='GTC'
            )
            self.sl_order.transmit = True

            trade = self.ib.placeOrder(self.contract, self.sl_order)
            self.ib.sleep(1.0)
            print("SL Order Status:", trade.orderStatus.status)
            if trade.orderStatus.status.lower() == "rejected":
                self._log_to_csv(
                    "Error",
                    f"OrderRejected - Stop Loss order rejected: {trade.log}"
                )
                return

            self._log_to_csv(
                "Stop Loss Placed",
                f"SL placed at {stop_price_index:.2f} | TP1: {((self.entry_price / self.multiplier) + self.config['tp1_points']) if is_long else ((self.entry_price / self.multiplier) - self.config['tp1_points'])} | TP2: {((self.entry_price / self.multiplier) + self.config['tp2_points']) if is_long else ((self.entry_price / self.multiplier) - self.config['tp2_points'])}"
            )

        except Exception as e:
            self._log_to_csv(
                "Error",
                f"ExecutionError - Exception in _initialize_position: {str(e)}"
            )


    def _execute_tp1(self, current_price, is_long):
        try:
            if self.original_size != 1:
                close_qty = round(self.original_size * 0.5)
                self._log_to_monitor( f"Position size {close_qty}  50% if {self.original_size > 1}")
            else:
                close_qty = self.original_size  # minimum allowed for TWS
                # self._log_to_monitor("WARN", f"Position size {self.original_size} too small for 50% close — closing full position.")


            if self.sl_order:
                self.ib.cancelOrder(self.sl_order)
                self.ib.sleep(0.5) 

            self.sl_order = MarketOrder(
                    'SELL' if is_long else 'BUY',
                    close_qty,
                    tif='GTC'
                )

            self.tp1_triggered = True
            trade = self.ib.placeOrder(self.contract, self.sl_order)
            self.ib.sleep(1.0)
            print("TP1 Order Status:", trade.orderStatus.status)


            # Always store TP1 fill price BEFORE re-arming SL
            if trade.orderStatus.avgFillPrice:
                self.tp1_fill_price = trade.orderStatus.avgFillPrice
            else:
                self.tp1_fill_price = current_price  # fallback

            self._log_to_monitor(f"TP1 Order ID: {trade.order.orderId}")
            self._log_to_monitor(f"TP1 Fill Price: {self.tp1_fill_price:.2f}")

            if trade.orderStatus.status.lower() == "rejected":
                self._log_error("Breakeven order rejected", error_type="OrderRejected")
                return "TP1 Error: rejected"

            self._log_to_csv(
                "TP1 Triggered",
                f"Closed {close_qty} contracts at {self.tp1_fill_price:.2f}, moved to breakeven"
            )

            # ✅ Immediately re-arm SL at TP1 fill price
            self._initialize_position(self.position)

            return f"TP1: Closed {close_qty} @ {current_price:.2f},  moved to breakeven"

        except Exception as e:
            self._log_error(str(e), error_type="Execution")
            return f"TP1 Error: {str(e)}"

    def _execute_tp2(self, current_price, is_long):
        try:
            if self.original_size != 1:
                close_qty = round(self.original_size * 0.9)
            else:
                close_qty = self.original_size

            
            self._close_position(close_qty, is_long)
            

            self.highest_price = current_price
            self._log_to_csv(
                    "TP2 Triggered",
                    f"Closed {close_qty} contracts at {current_price:.2f}, trailing stop activated"
                )
            return f"TP2: Closed {close_qty} @ {current_price:.2f}, Trailing SL activated"
        except Exception as e:
            self._log_error(str(e), error_type="Execution")
            return f"TP2 Error: {str(e)}"
    
    def _close_position(self, qty, is_long):
        try:
            action = 'SELL' if is_long else 'BUY'
            order = MarketOrder(action, qty)
            self.tp2_triggered = True
            self.ib.placeOrder(self.contract, order)

        except Exception as e:
            self._log_error(str(e), error_type="Execution")

    def _manage_trailing_stop(self, current_price, is_long):
        if self.highest_price is None:
            self.highest_price = current_price 

        if (is_long and current_price > self.highest_price) or (not is_long and current_price < self.highest_price):
            # Update highest/lowest price reached

            self.highest_price = current_price

            # Calculate trailing stop in market price (index points)
            trail_price = (
                self.highest_price - self.config['trailing_sl_points']
                if is_long else
                self.highest_price + self.config['trailing_sl_points']
            )

            # Align to MNQ tick size (0.25)
            trail_price = round(trail_price / 0.25) * 0.25

            # Cancel the old stop loss order
            self.ib.cancelOrder(self.sl_order)

            # Place new trailing stop order in market price format
            self.sl_order = StopOrder(
                'SELL' if is_long else 'BUY',
                max(1, self.original_size // 10),  # At least 1 contract
                trail_price,
                tif='GTC'
            )
            self.ib.placeOrder(self.contract, self.sl_order)

            # Log both market price and USD equivalent
            self._log_to_csv(
                "Trailing Stop Updated",
                f"Trail price: {trail_price:.2f}, Highest price: {self.highest_price:.2f}"
            )


            return f"Trailing SL updated to {trail_price:.2f}"

        return "Tracking price for trailing stop"


    def _cleanup(self):
        if self.sl_order:
            self.ib.cancelOrder(self.sl_order)
        self.position = None
        self.entry_price = None
        self.tp1_triggered = False
        self.tp2_triggered = False
        self.highest_price = None
